async function sendMessage() {
    const userInput = document.getElementById("user-input").value;
    const chatBox = document.getElementById("chat-box");

    chatBox.innerHTML += `<div class="user-message">You: ${userInput}</div>`;

    const response = await fetch('http://localhost:5000/support', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userInput }),
    });

    const data = await response.json();
    if (data.response) {
        chatBox.innerHTML += `<div class="bot-message">Bot: ${data.response}</div>`;
    } else {
        chatBox.innerHTML += `<div class="bot-message">Bot: Error occurred, please try again later.</div>`;
    }
    document.getElementById("user-input").value = "";
}
