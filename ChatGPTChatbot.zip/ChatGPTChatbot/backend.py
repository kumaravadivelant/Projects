import os
import re
from flask import Flask, request, jsonify
from flask_cors import CORS
from openai import OpenAI
import psycopg2





# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Instantiate the OpenAI client with API key from environment variable
api_key = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=api_key)
DATABASE_URL = os.getenv("DATABASE_URL")

def detect_intent(user_message):
    # Placeholder for an NLP model or API call for intent detection
    if re.search(r'\bbalance\b|\baccount\b|\btransaction\b', user_message.lower()):
        return "balance_inquiry"
    return "general_query"

def get_user_balance(username):
    try:
        print(f"connection {DATABASE_URL}")
        connection = psycopg2.connect(DATABASE_URL)
       
        cursor = connection.cursor()
        cursor.execute("SELECT balance FROM users WHERE name ILIKE  %s", (username,))
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        if result:
            return result[0]
        else:
            return None
    except Exception as e:
        print(f"Database error: {e}")
        return None

# Route for the root URL
@app.route('/')
def home():
    return "<h1>Welcome to the ChatGPT Customer Support Bot</h1><p>Use /support to interact with the bot.</p>"

# Route for handling customer support requests
@app.route('/support', methods=['POST'])
def customer_support():
    data = request.json
    user_message = data.get("message")
    username = data.get("user_name")

    print(f"user id {data}")
    if not user_message:
        return jsonify({"error": "No message provided"}), 400
 # Determine intent of user message
    intent = detect_intent(user_message)

    if intent == "balance_inquiry":
        user_balance = get_user_balance(username)
        if user_balance is not None:
            return jsonify({"response": f"Your current balance is ${user_balance:.2f}."})
        else:
            return jsonify({"response": "Sorry, we couldn't find your account information. Please try again."})
    else:
        try:
            # Create a chat completion using OpenAI client
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are a helpful customer support assistant."},
                    {"role": "user", "content": user_message}
                ],
                max_tokens=150,
                temperature=0.7
            )
            
            # Extract the assistant's response
            bot_reply = response.choices[0].message.content.strip()
            return jsonify({"response": bot_reply})
        except Exception as e:
            print(f"Error occurred: {e}")
            return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=5000, debug=True)
